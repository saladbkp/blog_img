<div style="width:300px; height:400px; color:#000000;">
  <div align="justify">
  <br ><strong>TERMS AND CONDITIONS OF WINGS CAFE.</strong></br>
  
  <br ><strong>* 30 minutes guarantee applies up to those who buy up to 30 maluti food and above.</strong></br>
    
   <br /><strong>*  Gurantee applies to students and Lecturers only.</strong></br>
    
    <br /><strong>* Guaranteed time maybe suspended depending on the weather conditions for the safety of our delivery riders.</strong></br>
    
   <br /><strong>* All prices quoted are in Maluti and rands only. Price and availability information is subject to change without notice.</strong></br>
    
   <br /><strong>* Mode of payment is strictly Cash.</strong></br>
  </div>
</div>
